﻿using Capgemini.JobPortalSystem.DataAccessLayer;
using Capgemini.JobPortalSystem.Entities;
using Capgemini.JobPortalSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.BusinessLogicLayer
{
    public class JobPortalSystemBLL
    {
        private bool ValidateJob(JobDetails job)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();
            if (job.Employer == string.Empty || job.Address == string.Empty || job.ContactEmailID == string.Empty 
                || job.SkillsRequired == string.Empty || job.Qualification == string.Empty || job.Location == string.Empty ||
                job.Salary == null || job.NoOfVacancies == null || job.ContactNumber == null)
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(job.Salary.ToString(), @"[1-9]{1}[0-9]{4,7}") && job.Salary != null)
            {
                validate = false;
                errorMessages.AppendLine("][ Salary must be between 10000 and 99999999 !!");
            }
            if (!Regex.IsMatch(job.NoOfVacancies.ToString(), @"[1-9]{1}[0-9]{1,2}") && job.NoOfVacancies != null)
            {
                validate = false;
                errorMessages.AppendLine("][ Vacancies must be between 1 and 999 !!");
            }
            if (!Regex.IsMatch(job.ContactNumber.ToString(), @"(6|7|8|9){1}[0-9]{9}") && job.ContactNumber!= null)
            {
                validate = false;
                errorMessages.AppendLine("][ Contact number must be of 10 digits, starting with 6, 7, 8 or 9 !!");
            }
            if (!Regex.IsMatch(job.Employer, @"^[a-zA-Z ]{3,50}$") && job.Employer != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Employer names must be non numeric and 3-50 characters long !!");
            }
            if (!Regex.IsMatch(job.Address, @"^.{3,100}$") && job.Address != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Address must be 3-100 characters long !!");
            }
            if (!Regex.IsMatch(job.SkillsRequired, @"^.{3,500}$") && job.SkillsRequired != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Skills field must be 3-500 characters long !!");
            }
            if (!Regex.IsMatch(job.Qualification, @"^.{3,50}$") && job.Qualification != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Qualification must be 3-50 characters long !!");
            }
            if (!Regex.IsMatch(job.Location, @"^[a-zA-Z ]{3,50}$") && job.Location != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Location must be non-numeric and 3-50 characters long !!");
            }
            if (!Regex.IsMatch(job.ContactEmailID, @".{3,100}\@[a-z]{3,10}\.[a-zA-Z0-9.]{3,15}"))
            {
                validate = false;
                errorMessages.AppendLine("][ Enter a valid email id !!");
            }

            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        private bool ValidateUser(UserInformation newUser)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();
            if (newUser.FirstName == string.Empty || newUser.LastName == string.Empty || newUser.Address == string.Empty ||
                newUser.Password == string.Empty || newUser.Age == null || newUser.Gender == null || newUser.PhoneNo == null)
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(newUser.FirstName, @"[a-zA-Z]{3,50}") && newUser.FirstName != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ First name must only contain letters and must be 3-50 characters long !!");
            }
            if (!Regex.IsMatch(newUser.LastName, @"[a-zA-Z]{3,50}") && newUser.LastName != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Last name must only contain letters and must be 3-50 characters long !!");
            }
            if (!Regex.IsMatch(newUser.Address, @".{3,100}") && newUser.Address != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Address must be 3-100 characters long !!");
            }
            if (newUser.Age < 18 || newUser.Age > 59)
            {
                validate = false;
                errorMessages.AppendLine("][ Age must be between 18 and 59 !!");
            }
            if (char.ToUpper(Convert.ToChar(newUser.Gender)) != 'M' && char.ToUpper(Convert.ToChar(newUser.Gender)) != 'F')
            {
                validate = false;
                errorMessages.AppendLine("][ Gender must either be M or F !!");
            }
            if (!Regex.IsMatch(newUser.PhoneNo.ToString(), @"(6|7|8|9){1}[0-9]{9}"))
            {
                validate = false;
                errorMessages.AppendLine("][ Contact number must be of 10 digits, starting with 6, 7, 8 or 9 !!");
            }
            if (!Regex.IsMatch(newUser.Password, @"[a-zA-Z]{6,100}") && newUser.Password != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Passwords must be 6-100 characters long !!");
            }
            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        private bool ValidateCredentials(LoginCredentials credentials)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();

            if (credentials.UserID == null || credentials.UserType == null || string.IsNullOrEmpty(credentials.Password))
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(credentials.UserID.ToString(), @"[1-9]{1}[0-9]{4}"))
            {
                validate = false;
                errorMessages.AppendLine("][ User ID must be of 5 digits and cannot start with 0 !!");
            }
            if (char.ToUpper(Convert.ToChar(credentials.UserType)) != 'A' && char.ToUpper(Convert.ToChar(credentials.UserType)) != 'U')
            {
                validate = false;
                errorMessages.AppendLine("][ User type can either be 'A' or 'U' !!");
            }
            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        public bool AddJob(JobDetails job, out int? jobId)
        {
            jobId = -1;
            bool jobAdded = false;
            try
            {
                if (ValidateJob(job))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    jobAdded = systemDAL.AddJob(job, out jobId);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobAdded;
        }
        public JobDetails SearchJob(int? jobId)
        {
            JobDetails job = null;
            try
            {
                if (!Regex.IsMatch(jobId.ToString(), @"[1-9]{1}[0-9]{6}") || jobId == null)
                    throw new JobPortalSystemException("][ Job ID must be of 7 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                job = systemDAL.SearchJob(jobId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return job;
        }
        public List<JobDetails> ViewAllJobs()
        {
            List<JobDetails> jobList = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobList = systemDAL.ViewAllJobs();
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobList;
        }
        public bool EditJob(JobDetails job)
        {
            bool jobEdited = false;
            try
            {
                if (ValidateJob(job))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    jobEdited = systemDAL.EditJob(job);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobEdited;
        }
        public bool DeleteJob(int? jobId)
        {
            bool jobDeleted = false;
            try
            {
                if (!Regex.IsMatch(jobId.ToString(), @"[1-9]{1}[0-9]{6}") || jobId == null)
                    throw new JobPortalSystemException("][ Job ID must be of 7 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobDeleted = systemDAL.DeleteJob(jobId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobDeleted;
        }
        public bool AddNewUser(UserInformation newUser, out int? userId)
        {
            userId = null;
            bool isAdded = false;
            try
            {
                if (ValidateUser(newUser))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    isAdded = systemDAL.AddNewUser(newUser, out userId);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return isAdded;
        }
        public bool UpdateUser(UserInformation user)
        {
            bool userEdited = false;
            try
            {
                if (!Regex.IsMatch(user.UserID.ToString(), @"[1-9]{1}[0-9]{4}") || user.UserID == null)
                    throw new JobPortalSystemException("][ User ID must be of 5 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userEdited = systemDAL.UpdateUser(user);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userEdited;
        }
        public bool DeleteUser(int? userId)
        {
            bool userDeleted = false;
            try
            {
                if (!Regex.IsMatch(userId.ToString(), @"[1-9]{1}[0-9]{4}") || userId == null)
                    throw new JobPortalSystemException("][ User ID must be of 5 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userDeleted = systemDAL.DeleteUser(userId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userDeleted;
        }
        public List<UserInformation> SearchUser(int? userId, string nameStart = null)
        {
            List<UserInformation> userList = null;
            try
            {
                if (!Regex.IsMatch(userId.ToString(), @"[1-9]{1}[0-9]{4}") && userId != null)
                    throw new JobPortalSystemException("][ User ID must be of 5 digits and cannot start with 0.");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userList = systemDAL.SearchUser(userId, nameStart);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userList;
        }
        public List<UserInformation> ViewAllUsers()
        {
            List<UserInformation> userList = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userList = systemDAL.ViewAllUsers();
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userList;
        }
        public bool Login(char userType, int userID, string pass)
        {
            LoginCredentials credentials = new LoginCredentials{
                UserType = userType,
                UserID = userID,
                Password = pass
            };
            bool credFound = false;
            try
            {
                if (ValidateCredentials(credentials))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    credFound = systemDAL.Login(userType, userID, pass);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return credFound;
        }
        public void StartUp(string fileName)
        {
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                systemDAL.StartUp(fileName);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
        }
    }
}

﻿using Capgemini.JobPortalSystem.DataAccessLayer;
using Capgemini.JobPortalSystem.Entities;
using Capgemini.JobPortalSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.BusinessLogicLayer
{
    public class JobPortalSystemBLL : JobPortalSystemBaseBLL
    {
        /// <summary>
        /// Validating the instance of JobDetails
        /// </summary>
        /// <returns>
        /// error messages if the validation fails else pass the request to the DAL
        /// </returns>
        public override bool ValidateJob(JobDetails job)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();
            if (job.Employer == string.Empty || job.Address == string.Empty || job.ContactEmailID == string.Empty 
                || job.SkillsRequired == string.Empty || job.Qualification == string.Empty || job.Location == string.Empty ||
                job.Salary == null || job.NoOfVacancies == null || job.ContactNumber == null)
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(job.Salary.ToString(), @"[1-9]{1}[0-9]{4,7}") && job.Salary != null)
            {
                validate = false;
                errorMessages.AppendLine("][ Salary must be between 10000 and 99999999 !!");
            }
            if (!Regex.IsMatch(job.NoOfVacancies.ToString(), @"[1-9]{1}[0-9]{1,2}") && job.NoOfVacancies != null)
            {
                validate = false;
                errorMessages.AppendLine("][ Vacancies must be between 1 and 999 !!");
            }
            if (!Regex.IsMatch(job.ContactNumber.ToString(), @"(6|7|8|9){1}[0-9]{9}") && job.ContactNumber!= null)
            {
                validate = false;
                errorMessages.AppendLine("][ Contact number must be of 10 digits, starting with 6, 7, 8 or 9 !!");
            }
            if (!Regex.IsMatch(job.Employer, @"^[a-zA-Z ]{3,50}$") && job.Employer != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Employer names must be non numeric and 3-50 characters long !!");
            }
            if (!Regex.IsMatch(job.Address, @"^.{3,100}$") && job.Address != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Address must be 3-100 characters long !!");
            }
            if (!Regex.IsMatch(job.SkillsRequired, @"^.{3,500}$") && job.SkillsRequired != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Skills field must be 3-500 characters long !!");
            }
            if (!Regex.IsMatch(job.Qualification, @"^.{3,50}$") && job.Qualification != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Qualification must be 3-50 characters long !!");
            }
            if (!Regex.IsMatch(job.Location, @"^[a-zA-Z ]{3,50}$") && job.Location != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Location must be non-numeric and 3-50 characters long !!");
            }
            if (!Regex.IsMatch(job.ContactEmailID, @".{3,100}\@[a-z]{3,10}\.[a-zA-Z0-9.]{3,15}"))
            {
                validate = false;
                errorMessages.AppendLine("][ Enter a valid email id !!");
            }

            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        /// <summary>
        /// Validating the instance of UserrInformation
        /// </summary>
        /// <returns>
        ///  error messages if the validation fails else pass the request to the DAL
        /// </returns>
        public override bool ValidateUser(UserInformation newUser)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();
            if (newUser.FirstName == string.Empty || newUser.LastName == string.Empty || newUser.Address == string.Empty ||
                newUser.Password == string.Empty || newUser.Age == null || newUser.Gender == null || newUser.PhoneNo == null)
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(newUser.FirstName, @"[a-zA-Z]{3,50}") && newUser.FirstName != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ First name must only contain letters and must be 3-50 characters long !!");
            }
            if (!Regex.IsMatch(newUser.LastName, @"[a-zA-Z]{3,50}") && newUser.LastName != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Last name must only contain letters and must be 3-50 characters long !!");
            }
            if (!Regex.IsMatch(newUser.Address, @".{3,100}") && newUser.Address != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Address must be 3-100 characters long !!");
            }
            if (newUser.Age < 18 || newUser.Age > 59)
            {
                validate = false;
                errorMessages.AppendLine("][ Age must be between 18 and 59 !!");
            }
            if (char.ToUpper(Convert.ToChar(newUser.Gender)) != 'M' && char.ToUpper(Convert.ToChar(newUser.Gender)) != 'F')
            {
                validate = false;
                errorMessages.AppendLine("][ Gender must either be M or F !!");
            }
            if (!Regex.IsMatch(newUser.PhoneNo.ToString(), @"(6|7|8|9){1}[0-9]{9}"))
            {
                validate = false;
                errorMessages.AppendLine("][ Contact number must be of 10 digits, starting with 6, 7, 8 or 9 !!");
            }
            if (!Regex.IsMatch(newUser.Password, @"[a-zA-Z]{6,100}") && newUser.Password != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Passwords must be 6-100 characters long !!");
            }
            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        /// <summary>
        /// Validating the instance of LofinCredentials
        /// </summary>
        /// <returns>
        ///  error messages if the validation fails else pass the request to the DAL
        /// </returns>
        public override bool ValidateCredentials(LoginCredentials credentials)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();

            if (credentials.UserID == null || credentials.UserType == null || string.IsNullOrEmpty(credentials.Password))
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(credentials.UserID.ToString(), @"[1-9]{1}[0-9]{4}"))
            {
                validate = false;
                errorMessages.AppendLine("][ User ID must be of 5 digits and cannot start with 0 !!");
            }
            if (char.ToUpper(Convert.ToChar(credentials.UserType)) != 'A' && char.ToUpper(Convert.ToChar(credentials.UserType)) != 'U')
            {
                validate = false;
                errorMessages.AppendLine("][ User type can either be 'A' or 'U' !!");
            }
            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        // Summary:
        //     Accept the details of Capgemini.JobPortalSystem.Entities.JobDetails instance,
        //     then passes it to the DAL. Throws an exception in case of failure.
        //
        // Parameters:
        //   job:
        //     The instance of the jobDetails to be added.
        //   jobId
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool AddJob(JobDetails job, out int? jobId)
        {
            jobId = -1;
            bool jobAdded = false;
            try
            {
                if (ValidateJob(job))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    jobAdded = systemDAL.AddJob(job, out jobId);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobAdded;
        }
        // Summary:
        //     Accepts the jobId  from the presentationLayer,
        //     then passes it to DAL. If found, returns the instance of the jobdetails.
        //
        // Parameters:
        //   jobId:
        //     The jobId of the jobDetails whose details needs to be displayed.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override JobDetails SearchJob(int? jobId)
        {
            JobDetails job = null;
            try
            {
                if (!Regex.IsMatch(jobId.ToString(), @"[1-9]{1}[0-9]{6}") || jobId == null)
                    throw new JobPortalSystemException("][ Job ID must be of 7 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                job = systemDAL.SearchJob(jobId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return job;
        }
        //summary:
        //View all the jobs
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override List<JobDetails> ViewAllJobs()
        {
            List<JobDetails> jobList = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobList = systemDAL.ViewAllJobs();
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobList;
        }
        // Summary:
        //     Accept the updtaed instance of Capgemini.JobPortalSystem.Entities.JobDetails ,
        //     then passes it to the DAL. Throws an exception in case of failure.
        //
        // Parameters:
        //   job:
        //     The instance of jobDetails to be edited.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool EditJob(JobDetails job)
        {
            bool jobEdited = false;
            try
            {
                if (ValidateJob(job))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    jobEdited = systemDAL.EditJob(job);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobEdited;
        }
        // Summary:
        //     Accept the jobId from Presentation Layer, validate it,
        //     then passes it to the DAL.
        //
        // Parameters:
        //   jobId:
        //     The jobId of the jobDetails whose instance needs to be removed.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool DeleteJob(int? jobId)
        {
            bool jobDeleted = false;
            try
            {
                if (!Regex.IsMatch(jobId.ToString(), @"[1-9]{1}[0-9]{6}") || jobId == null)
                    throw new JobPortalSystemException("][ Job ID must be of 7 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobDeleted = systemDAL.DeleteJob(jobId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobDeleted;
        }
        // Summary:
        //     Accept the instance of Capgemini.JobPortalSystem.Entities.UserInformation as a parameter,
        //    validate the enteries,pass it to the DAL. Throws an exception
        //     in case of failure.
        //
        // Parameters:
        //   newUser:
        //     The instance of the user to be added.
        //   userId:
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool AddNewUser(UserInformation newUser, out int? userId)
        {
            userId = null;
            bool isAdded = false;
            try
            {
                if (ValidateUser(newUser))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    isAdded = systemDAL.AddNewUser(newUser, out userId);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return isAdded;
        }
        // Summary:
        //     Accept the updtaed instance of Capgemini.JobPortalSystem.Entities.UserInformation ,
        //     then passes it to the DAL. Throws an exception in case of failure.
        //
        // Parameters:
        //   user:
        //     The instance of UserInormation to be edited.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool UpdateUser(UserInformation user)
        {
            bool userEdited = false;
            try
            {
                if (!Regex.IsMatch(user.UserID.ToString(), @"[1-9]{1}[0-9]{4}") || user.UserID == null)
                    throw new JobPortalSystemException("][ User ID must be of 5 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userEdited = systemDAL.UpdateUser(user);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userEdited;
        }
        // Summary:
        //     Accept the userId from Presentation Layer, validate it,
        //     then passes it to the DAL.
        //
        // Parameters:
        //   userId:
        //     The userId of the UserInformation whose instance needs to be removed.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool DeleteUser(int? userId)
        {
            bool userDeleted = false;
            try
            {
                if (!Regex.IsMatch(userId.ToString(), @"[1-9]{1}[0-9]{4}") || userId == null)
                    throw new JobPortalSystemException("][ User ID must be of 5 digits and cannot start with 0. It cannot be left blank !!");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userDeleted = systemDAL.DeleteUser(userId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userDeleted;
        }
        // Summary:
        //     Accepts the userId and nameStart from the presentationLayer,
        //     then passes it to BLL. If found, returns the instance of the User.
        //
        // Parameters:
        //   userId:
        //     The userId of the user whose details needs to be displayed.
        //   nameStart:
        //     The starting name of the users whose details needs to be searched.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.OnlineVehicleShowroom.Exception.ShowroomException
        public override List<UserInformation> SearchUser(int? userId, string nameStart = null)
        {
            List<UserInformation> userList = null;
            try
            {
                if (!Regex.IsMatch(userId.ToString(), @"[1-9]{1}[0-9]{4}") && userId != null)
                    throw new JobPortalSystemException("][ User ID must be of 5 digits and cannot start with 0.");
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userList = systemDAL.SearchUser(userId, nameStart);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userList;
        }
        //summary:
        //View all the users
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override List<UserInformation> ViewAllUsers()
        {
            List<UserInformation> userList = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userList = systemDAL.ViewAllUsers();
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userList;
        }
        //summary:
        //     Accept the instance of Capgemini.JobPortalSystem.Entities.LoginCredentials as a parameter,
        //     validate the enteries,Throws an exception
        //     in case of failure. 
        //Parameter:
        //     userType:
        //      checks whether the user is Admin or jobSeeker
        //     UserID:
        //      the instance of userId of the LoginCredentials to be verified
        //      pass:
        //       the instance of pass of the LoginCredentials to be verified
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool Login(char userType, int userID, string pass)
        {
            LoginCredentials credentials = new LoginCredentials{
                UserType = userType,
                UserID = userID,
                Password = pass
            };
            bool credFound = false;
            try
            {
                if (ValidateCredentials(credentials))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    credFound = systemDAL.Login(userType, userID, pass);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return credFound;
        }
        //
        // Summary:
        //     Calls the startup method of BLL class.
        //
        // Exceptions:
        //   T:Capgemini.JobPortalSystemException
        public override void StartUp(string fileName)
        {
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                systemDAL.StartUp(fileName);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
        }
    }
}

﻿using Capgemini.JobPortalSystem.DataAccessLayer;
using Capgemini.JobPortalSystem.Entities;
using Capgemini.JobPortalSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.BusinessLogicLayer
{
    public class JobPortalSystemBLL
    {
        private bool ValidateJob(JobDetails job)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();
            if (job.Employer == string.Empty || job.Address == string.Empty || job.ContactEmailID == string.Empty 
                || job.SkillsRequired == string.Empty || job.Qualification == string.Empty || job.Location == string.Empty ||
                job.Salary == null || job.NoOfVacancies == null || job.ContactNumber == null)
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (job.Salary < 10000 || job.Salary > 99999999)
            {
                validate = false;
                errorMessages.AppendLine("][ Salary must be between 10000 and 99999999 !!");
            }
            if (job.NoOfVacancies < 1 || job.NoOfVacancies > 1000)
            {
                validate = false;
                errorMessages.AppendLine("][ Vacancies must be between 1 and 1000 !!");
            }
            if (!Regex.IsMatch(job.ContactNumber.ToString(), @"(6|7|8|9){1}[0-9]{9}"))
            {
                validate = false;
                errorMessages.AppendLine("][ Contact number must be of 10 digits, starting with 6, 7, 8 or 9 !!");
            }
            if (job.Employer.Length < 3 && job.Employer != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Employer names with length less than 3 are considered invalid !!");
            }
            if (job.Address.Length < 3 && job.Address != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Address with length less than 3 are considered invalid !!");
            }
            if (job.SkillsRequired.Length < 3 && job.SkillsRequired != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Skill names with length less than 3 are considered invalid !!");
            }
            if (job.Qualification.Length < 3 && job.Qualification != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Qualification names with length less than 3 are considered invalid !!");
            }
            if (job.Location.Length < 3 && job.Location != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Location names with length less than 3 are considered invalid !!");
            }
            //EMAIL ID TO BE VALIDATED
            //if (!Regex.IsMatch(job.ContactEmailID, @".*{3, 10}@[a-z]{3, 10}.[a-zA-Z0-9.@]{3, 50}"))
            //{
            //    validate = false;
            //    errorMessages.AppendLine("][ Address with length less than 3 are considered invalid !!");
            //}

            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        private bool ValidateUser(UserInformation newUser)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();
            if (newUser.FirstName == string.Empty || newUser.LastName == string.Empty || newUser.Address == string.Empty ||
                newUser.Password == string.Empty || newUser.Age == null || newUser.Gender == null || newUser.PhoneNo == null)
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (newUser.Age < 18 || newUser.Age > 59)
            {
                validate = false;
                errorMessages.AppendLine("][ Age must be between 18 and 59 !!");
            }
            if (newUser.Gender != 'M' && newUser.Gender != 'F')
            {
                validate = false;
                errorMessages.AppendLine("][ Gender must either be M or F !!");
            }
            if (!Regex.IsMatch(newUser.PhoneNo.ToString(), @"(6|7|8|9){1}[0-9]{9}"))
            {
                validate = false;
                errorMessages.AppendLine("][ Contact number must be of 10 digits, starting with 6, 7, 8 or 9 !!");
            }
            if (newUser.FirstName.Length < 3 && newUser.FirstName != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ First names with length less than 3 are considered invalid !!");
            }
            if (newUser.LastName.Length < 3 && newUser.LastName != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Last names with length less than 3 are considered invalid !!");
            }
            if (newUser.Address.Length < 3 && newUser.Address != string.Empty)
            {
                validate = false;
                errorMessages.AppendLine("][ Address with length less than 3 are considered invalid !!");
            }
            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        private bool ValidateCredentials(LoginCredentials credentials)
        {
            bool validate = true;
            StringBuilder errorMessages = new StringBuilder();

            if (credentials.UserID == null || credentials.UserType == null || string.IsNullOrEmpty(credentials.Password))
            {
                validate = false;
                errorMessages.AppendLine("][ None of the fields can be left blank !!");
            }
            if (!Regex.IsMatch(credentials.UserID.ToString(), @"[1-9]{1}[0-9]{4}"))
            {
                validate = false;
                errorMessages.AppendLine("][ User ID must be of 5 digits and cannot start with 0 !!");
            }
            if (credentials.UserType != 'A' && credentials.UserType != 'U')
            {
                validate = false;
                errorMessages.AppendLine("][ User type can either be 'A' or 'U' !!");
            }
            if (!validate)
            {
                throw new JobPortalSystemException(errorMessages.ToString() + "\a");
            }
            return validate;
        }
        public bool AddJob(JobDetails job, out int? jobId)
        {
            jobId = -1;
            bool jobAdded = false;
            try
            {
                if (ValidateJob(job))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    jobAdded = systemDAL.AddJob(job, out jobId);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobAdded;
        }
        public JobDetails SearchJob(int jobId)
        {
            JobDetails job = new JobDetails();
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                job = systemDAL.SearchJob(jobId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return job;
        }
        public List<JobDetails> ViewAllJobs()
        {
            List<JobDetails> jobList = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobList = systemDAL.ViewAllJobs();
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobList;
        }
        public bool EditJob(JobDetails job)
        {
            bool jobEdited = false;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobEdited = systemDAL.EditJob(job);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobEdited;
        }
        public bool DeleteJob(int jobId)
        {
            bool jobDeleted = false;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                jobDeleted = systemDAL.DeleteJob(jobId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return jobDeleted;
        }
        public bool AddNewUser(UserInformation newUser, out int? userId)
        {
            userId = null;
            bool isAdded = false;
            try
            {
                if (ValidateUser(newUser))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    isAdded = systemDAL.AddNewUser(newUser, out userId);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return isAdded;
        }
        public bool UpdateUser(UserInformation user)
        {
            bool userEdited = false;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userEdited = systemDAL.UpdateUser(user);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userEdited;
        }
        public bool DeleteUser(int userId)
        {
            bool userDeleted = false;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userDeleted = systemDAL.DeleteUser(userId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userDeleted;
        }
        public UserInformation SearchUser(int userId, string password)
        {
            UserInformation user = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                user = systemDAL.SearchUser(userId, password);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return user;
        }
        public UserInformation SearchUser(int userId)
        {
            UserInformation user = new UserInformation();
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                user = systemDAL.SearchUser(userId);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return user;
        }
        public List<UserInformation> ViewAllUsers()
        {
            List<UserInformation> userList = null;
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                userList = systemDAL.ViewAllUsers();
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return userList;
        }
        public bool Login(char userType, int userID, string pass)
        {
            LoginCredentials credentials = new LoginCredentials{
                UserType = userType,
                UserID = userID,
                Password = pass
            };
            bool credFound = false;
            try
            {
                if (ValidateCredentials(credentials))
                {
                    JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                    credFound = systemDAL.Login(userType, userID, pass);
                }
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
            return credFound;
        }
        public void StartUp(string fileName)
        {
            try
            {
                JobPortalSystemDAL systemDAL = new JobPortalSystemDAL();
                systemDAL.StartUp(fileName);
            }
            catch (JobPortalSystemException)
            {
                throw;
            }
        }
    }
}

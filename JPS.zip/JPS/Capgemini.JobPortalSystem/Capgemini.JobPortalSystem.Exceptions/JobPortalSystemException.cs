﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.Exceptions
{
    public class JobPortalSystemException : ApplicationException
    {
        public JobPortalSystemException()
        {
        }

        public JobPortalSystemException(string message) : base(message)
        {
        }

        public JobPortalSystemException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected JobPortalSystemException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}

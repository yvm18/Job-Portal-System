﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.Exceptions
{
    /// <summary>
    /// serves as the base class for JobPortalSystemException.
    /// Inherits from System.Application.Exception
    /// </summary>
    public class JobPortalSystemException : ApplicationException
    {
        // Initializes the instances of Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        // using the base class default constructor.
        public JobPortalSystemException()
        {
        }
        //Initializes the instances of Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        //using the base class parameterized constructor.
        // Parameters:
        // message:
        // The message value of the exception in the string format.
        public JobPortalSystemException(string message) : base(message)
        {
        }
        //Initializes the instances of Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        //using the overloaded base class constructor.
        //Parameters:
        //message:
        //The message value of the exception in the string format.
        //innerException:The inner exception, if any.   
        public JobPortalSystemException(string message, System.Exception innerException) : base(message, innerException)
        {
        }
        //Initializes the instances of Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        //using the overloaded base class constructor.
        //Parameters:
        //info:
        //serailization information(type of serialization).
        //icontext: Context  
        protected JobPortalSystemException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}

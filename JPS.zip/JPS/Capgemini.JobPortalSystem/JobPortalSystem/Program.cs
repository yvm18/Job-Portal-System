﻿using Capgemini.JobPortalSystem.BusinessLogicLayer;
using Capgemini.JobPortalSystem.Entities;
using Capgemini.JobPortalSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Capgemini.JobPortalSystem.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            StartUp();
            Menu();
            Console.Read();
        }
        private static void InitializeConsole()
        {
            Console.Clear();
            Console.SetCursorPosition(Console.WindowWidth / 2, 0);
            Console.WriteLine("JOB PORTAL SYSTEM");
        }
        private static void Menu()
        {
            int ch;
            InitializeConsole();
            Console.WriteLine("1.] ADMINISTRATOR");
            Console.WriteLine("2.] USER");
            Console.WriteLine("3.] EXIT");

            Console.Write("\nEnter your choice: ");

            while (!int.TryParse(Console.ReadLine(), out ch))
                Console.Write("Enter your choice [NUMBER]: ");
            switch (ch)
            {
                case 1:
                    Login('A');
                    Console.ReadLine();
                    Menu();
                    break;
                case 2:
                    UserHomeScreen();
                    Console.ReadLine();
                    Menu();
                    break;
                case 3:
                    Quit();
                    break;
                default:
                    Console.WriteLine("Invalid choice !!");
                    Console.ReadLine();
                    Menu();
                    break;
            }
        }
        private static void UserHomeScreen()
        {
            int ch;
            InitializeConsole();
            Console.WriteLine("\n1.] Register/Sign Up");
            Console.WriteLine("2.] Sign In");
            Console.WriteLine("3.] Main Menu");

            Console.Write("\nEnter your choice: ");

            while (!int.TryParse(Console.ReadLine(), out ch))
                Console.Write("Enter your choice [NUMBER]: ");
            switch (ch)
            {
                case 1:
                    UserSignUp();
                    Console.ReadLine();
                    UserHomeScreen();
                    break;
                case 2:
                    Login('U');
                    Console.ReadLine();
                    UserHomeScreen();
                    break;
                case 3:
                    Menu();
                    break;
                default:
                    Console.WriteLine("Invalid choice !!");
                    Console.ReadLine();
                    UserHomeScreen();
                    break;
            }
        }
        private static void UserPanel(UserInformation user)
        {
            try
            {
                int ch;
                InitializeConsole();
                Console.SetCursorPosition(Console.WindowWidth / 2, 2);
                Console.WriteLine("Welcome " + user.FirstName);
                Console.SetCursorPosition(Console.WindowWidth / 2, 3);
                Console.WriteLine(user.UserType == 'A' ? "Administrator" : "Job Seeker");
                Console.SetCursorPosition(Console.WindowWidth / 2, 4);
                Console.WriteLine("ID: " + user.UserID);
                Console.WriteLine("\n");
                Console.WriteLine("1.] Search/View Jobs");
                Console.WriteLine("2.] View all jobs");
                Console.WriteLine("3.] Logout");

                Console.Write("\nEnter your choice: ");

                while (!int.TryParse(Console.ReadLine(), out ch))
                    Console.Write("Enter your choice [NUMBER]: ");
                switch (ch)
                {
                    case 1:
                        SearchJob();
                        Console.ReadLine();
                        UserPanel(user);
                        break;
                    case 2:
                        ViewAllJobs();
                        Console.ReadLine();
                        UserPanel(user);
                        break;
                    case 3:
                        UserHomeScreen();
                        break;
                    default:
                        Console.WriteLine("Invalid choice !!");
                        Console.ReadLine();
                        UserPanel(user);
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void AdminPanel(UserInformation user)
        {
            int ch;
            InitializeConsole();
            Console.SetCursorPosition(Console.WindowWidth / 2, 2);
            Console.WriteLine("Welcome " + user.FirstName);
            Console.SetCursorPosition(Console.WindowWidth / 2, 3);
            Console.WriteLine(user.UserType == 'A' ? "Administrator" : "Job Seeker");
            Console.SetCursorPosition(Console.WindowWidth / 2, 4);
            Console.WriteLine("ID: " + user.UserID);
            Console.WriteLine("\n");
            Console.WriteLine("1.] Add new job");
            Console.WriteLine("2.] Edit job details");
            Console.WriteLine("3.] Delete a job");
            Console.WriteLine("4.] Search/View Jobs");
            Console.WriteLine("5.] View all jobs");
            Console.WriteLine("6.] Add new user");
            Console.WriteLine("7.] Update user");
            Console.WriteLine("8.] Delete user");
            Console.WriteLine("9.] Search/View user");
            Console.WriteLine("10.] View all users");
            Console.WriteLine("11.] Logout");

            Console.Write("\nEnter your choice: ");

            while (!int.TryParse(Console.ReadLine(), out ch))
                Console.Write("Enter your choice [NUMBER]: ");
            switch (ch)
            {
                case 1:
                    AddJob();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 2:
                    EditJob();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 3:
                    DeleteJob();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 4:
                    SearchJob();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 5:
                    ViewAllJobs();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 6:
                    UserSignUp();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 7:
                    UpdateUser();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 8:
                    DeleteUser();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 9:
                    SearchUser();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 10:
                    ViewAllUsers();
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
                case 11:
                    Menu();
                    break;
                default:
                    Console.WriteLine("Invalid choice !!");
                    Console.ReadLine();
                    AdminPanel(user);
                    break;
            }
        }
        private static void AddJob()
        {
            int temp;
            long tmp;
            try
            {
                JobDetails job = new JobDetails();
                JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
                Console.Write("Enter employer: ");
                job.Employer = Console.ReadLine();
                Console.Write("Enter address: ");
                job.Address = Console.ReadLine();
                Console.Write("Enter contact number: ");
                while (!long.TryParse(Console.ReadLine(), out tmp))
                    Console.Write("Enter contact number [Numeric]: ");
                job.ContactNumber = tmp;
                Console.Write("Enter email ID: ");
                job.ContactEmailID = Console.ReadLine();
                Console.Write("Enter skills: ");
                job.SkillsRequired = Console.ReadLine();
                Console.Write("Enter qualification: ");
                job.Qualification = Console.ReadLine();
                Console.Write("Enter location: ");
                job.Location = Console.ReadLine();
                Console.Write("Enter salary: ");
                while (!int.TryParse(Console.ReadLine(), out temp))
                    Console.Write("Enter salary [Numeric]: ");
                job.Salary = temp;
                Console.Write("Enter no of vacancies: ");
                while (!int.TryParse(Console.ReadLine(), out temp))
                    Console.Write("Enter no of vacancies [Numeric]: ");
                job.NoOfVacancies = temp;
                bool jobAdded = systemBLL.AddJob(job, out int? jobId);
                
                if (jobAdded == true && jobId != -1)
                    Console.WriteLine($"\nAssigned job id is " + jobId);
                else
                    Console.WriteLine("OOh! Job could not be added !!");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void SearchJob()
        {
            JobDetails job = null;
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            try
            {
                int jobId;
                int? jobID = null;
                Console.Write("Enter a job id: ");
                while (!int.TryParse(Console.ReadLine(), out jobId))
                    Console.Write("Enter job id [7-digit Numeric]: ");
                jobID = jobId;
                job = systemBLL.SearchJob(jobID);

                if (job != null)
                    Console.WriteLine(job.ToString());
                else
                    Console.WriteLine("OOh! Job not found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void ViewAllJobs()
        {
            List<JobDetails> jobList = null;
            try
            {
                JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
                jobList = systemBLL.ViewAllJobs();
                if (jobList != null)
                {
                    Console.Clear();
                    InitializeConsole();
                    foreach (JobDetails job in jobList)
                        Console.WriteLine(job.ToString());
                }
                else
                    Console.WriteLine("OOh! No jobs found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void EditJob()
        {
            JobDetails job = null;
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            int jobId;
            try
            {
                Console.Write("Enter a job id: ");
                while (!int.TryParse(Console.ReadLine(), out jobId))
                    Console.Write("Enter job id [Numeric]: ");

                if (!Regex.IsMatch(jobId.ToString(), @"[1-9]{1}[0-9]{6}"))
                    throw new JobPortalSystemException("][ Job ID must be of 7 digits and cannot start with 0 !!");
                else
                {
                    job = systemBLL.SearchJob(jobId);

                    if (job != null)
                    {
                        JobDetails newJob = new JobDetails();
                        string sTemp;
                        long lTemp;
                        int iTemp;
                        newJob.JobID = job.JobID;
                        Console.Write("Enter employer: ");
                        newJob.Employer = (sTemp = Console.ReadLine()) == string.Empty ? job.Employer : sTemp;
                        Console.Write("Enter address: ");
                        newJob.Address = (sTemp = Console.ReadLine()) == string.Empty ? job.Address : sTemp;
                        Console.Write("Enter contact number: ");
                        while (!long.TryParse(Console.ReadLine(), out lTemp))
                            Console.Write("Enter contact number [Numeric]: ");
                        newJob.ContactNumber = lTemp;
                        Console.Write("Enter email ID: ");
                        newJob.ContactEmailID = (sTemp = Console.ReadLine()) == string.Empty ? job.ContactEmailID : sTemp;
                        Console.Write("Enter skills: ");
                        newJob.SkillsRequired = (sTemp = Console.ReadLine()) == string.Empty ? job.SkillsRequired : sTemp;
                        Console.Write("Enter qualification: ");
                        newJob.Qualification = (sTemp = Console.ReadLine()) == string.Empty ? job.Qualification : sTemp;
                        Console.Write("Enter location: ");
                        newJob.Location = (sTemp = Console.ReadLine()) == string.Empty ? job.Location : sTemp;
                        Console.Write("Enter salary: ");
                        while (!int.TryParse(Console.ReadLine(), out iTemp))
                            Console.Write("Enter salary [Numeric]: ");
                        newJob.Salary = iTemp;
                        Console.Write("Enter no of vacancies: ");
                        while (!int.TryParse(Console.ReadLine(), out iTemp))
                            Console.Write("Enter no of vacancies [Numeric]: ");
                        newJob.NoOfVacancies = iTemp;
                        bool jobEdited = systemBLL.EditJob(newJob);
                        if (jobEdited)
                            Console.WriteLine("Job details updated successfully.");
                        else
                            Console.WriteLine("OOh! Job details could not be updated !!");
                    }
                    else
                        Console.WriteLine("OOh! Job not found !!");
                }
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void DeleteJob()
        {
            JobDetails job = null;
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            int jobId;
            int? jobID = null;
            bool jobDeleted =false;
            try
            {
                Console.Write("Enter a job id: ");
                while (!int.TryParse(Console.ReadLine(), out jobId))
                    Console.Write("Enter job id [Numeric]: ");
                jobID = jobId;
                job = systemBLL.SearchJob(jobID);

                if (job != null)
                {
                    jobDeleted = systemBLL.DeleteJob(jobId);
                    if (jobDeleted)
                        Console.WriteLine("Job successfully deleted.");
                    else
                        Console.WriteLine("OOh! Job could not be deleted !!");
                }
                else
                    Console.WriteLine("OOh! Job not found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void UserSignUp()
        {
            UserInformation newUser = new UserInformation();
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            int iTemp;
            char cTemp;
            long lTemp;
            try
            {
                Console.Write("Enter first name: ");
                newUser.FirstName = Console.ReadLine();
                Console.Write("Enter last name: ");
                newUser.LastName = Console.ReadLine();
                Console.Write("Enter age: ");
                while (!int.TryParse(Console.ReadLine(), out iTemp))
                    Console.Write("Enter age [Numeric]: ");
                newUser.Age = iTemp;
                Console.Write("Enter gender: ");
                while (!char.TryParse(Console.ReadLine(), out cTemp))
                    Console.Write("Enter gender [Numeric]: ");
                newUser.Gender = cTemp;
                Console.Write("Enter address: ");
                newUser.Address = Console.ReadLine();
                Console.Write("Enter phone number: ");
                while (!long.TryParse(Console.ReadLine(), out lTemp))
                    Console.Write("Enter phone number [Numeric]: ");
                newUser.PhoneNo = lTemp;
                Console.Write("Enter password for your user account: ");
                newUser.Password = readPassword();
                newUser.UserType = 'U';
                if (systemBLL.AddNewUser(newUser, out int? userId))
                    Console.WriteLine("User added successfully. Assigned ID is " + userId);
                else
                    Console.WriteLine("OOh! User could not be registered !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void UpdateUser()
        {
            UserInformation user = null;
            List<UserInformation> userList = null;
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            int userId;
            try
            {
                Console.Write("Enter user id: ");
                while (!int.TryParse(Console.ReadLine(), out userId))
                    Console.Write("Enter user id [Numeric]: ");

                userList = systemBLL.SearchUser(userId);
                if (userList != null && userList.Count != 0)
                    user = systemBLL.SearchUser(userId)[0];

                if (user != null)
                {
                    string sTemp;
                    long lTemp;
                    int iTemp;
                    char cTemp;
                    Console.Write("Enter First Name: ");
                    user.FirstName = (sTemp = Console.ReadLine()) == string.Empty ? user.FirstName : sTemp;
                    Console.Write("Enter Last Name: ");
                    user.LastName = (sTemp = Console.ReadLine()) == string.Empty ? user.LastName : sTemp;
                    Console.Write("Enter age: ");
                    while (!int.TryParse(Console.ReadLine(), out iTemp))
                        Console.Write("Enter age [Numeric]: ");
                    user.Age = iTemp;
                    Console.Write("Enter gender: ");
                    while (!char.TryParse(Console.ReadLine(), out cTemp))
                        Console.Write("Enter gender [M | F]: ");
                    user.Gender = cTemp;
                    Console.Write("Enter Address: ");
                    user.Address = (sTemp = Console.ReadLine()) == string.Empty ? user.Address : sTemp;
                    Console.Write("Enter phone no: ");
                    while (!long.TryParse(Console.ReadLine(), out lTemp))
                        Console.Write("Enter phone no. [Numeric]: ");
                    user.PhoneNo = lTemp;
                    Console.Write("Enter user type: ");
                    while (!char.TryParse(Console.ReadLine(), out cTemp))
                        Console.Write("Enter user type [A | U]: ");
                    user.UserType = cTemp;
                    bool userEdited = systemBLL.UpdateUser(user);
                    if (userEdited)
                        Console.WriteLine("User details updated successfully.");
                    else
                        Console.WriteLine("OOh! User details could not be updated !!");
                }
                else
                    Console.WriteLine("OOh! User not found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void DeleteUser()
        {
            UserInformation user = null;
            List<UserInformation> userList = null;
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            int userId;
            bool userDeleted = false;
            try
            {
                Console.Write("Enter user id: ");
                while (!int.TryParse(Console.ReadLine(), out userId))
                    Console.Write("Enter user id [Numeric]: ");

                userList = systemBLL.SearchUser(userId);
                if (userList != null && userList.Count != 0)
                    user = systemBLL.SearchUser(userId)[0];
                

                if (user != null)
                {
                    userDeleted = systemBLL.DeleteUser(userId);
                    if (userDeleted)
                        Console.WriteLine("User successfully deleted.");
                    else
                        Console.WriteLine("OOh! User could not be deleted !!");
                }
                else
                    Console.WriteLine("OOh! User not found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void SearchUser()
        {
            List<UserInformation> userList = null;
            JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
            int? userID = null;
            string nameStart = null;
            int ch;

            try
            {
                Console.WriteLine("1.] Search by Job ID");
                Console.WriteLine("2.] Search by name starts with");
                Console.Write("\nEnter your choice: ");

                while (!int.TryParse(Console.ReadLine(), out ch))
                    Console.Write("Enter your choice [NUMBER]: ");
                if (ch == 1)
                {
                    int userId;
                    Console.Write("Enter a user id: ");
                    while (!int.TryParse(Console.ReadLine(), out userId))
                        Console.Write("Enter a user id [Numeric]: ");
                    userID = userId;
                }
                else if (ch == 2)
                {
                    Console.Write("Enter starting characters of a name: ");
                    while (string.IsNullOrEmpty(nameStart = Console.ReadLine()))
                        Console.Write("Enter starting characters of a name [Cannot be blank]: ");
                }
                userList = systemBLL.SearchUser(userID, nameStart);
                if (userList != null && userList.Count != 0)
                    foreach (UserInformation user in userList)
                        Console.WriteLine(user.ToString());
                else
                    Console.WriteLine("OOh! User not found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void ViewAllUsers()
        {
            List<UserInformation> userList = null;
            try
            {
                JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
                userList = systemBLL.ViewAllUsers();
                if (userList != null)
                {
                    Console.Clear();
                    InitializeConsole();
                    foreach (UserInformation user in userList)
                        Console.WriteLine(user.ToString());
                }
                else
                    Console.WriteLine("OOh! No users found !!");
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static void Login(char userType)
        {
            InitializeConsole();
            Console.SetCursorPosition((Console.WindowWidth / 2) + 5, 1);
            Console.WriteLine("Login");
            int userID;
            string pass;
            UserInformation user = null;
            List<UserInformation> userList = null;
            try
            {
                JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
                Console.Write("Enter User ID: ");
                while (!int.TryParse(Console.ReadLine(), out userID))
                    Console.Write("Enter User ID [5-DIGIT, NUMERIC, NOT STARTING WITH 0]: ");

                Console.Write("Enter Password: ");
                pass = readPassword();

                //  apply validation for user id and pass here

                bool credFound = systemBLL.Login(userType, userID, pass);
                if (credFound)
                {
                    InitializeConsole();

                    userList = systemBLL.SearchUser(userID);
                    if (userList != null && userList.Count != 0)
                        user = systemBLL.SearchUser(userID)[0];
                    if (user != null)
                    {
                        if (user.UserType == 'A')
                            AdminPanel(user);
                        else
                            UserPanel(user);
                    }
                    else
                    {
                        Console.WriteLine("OOh! User not found !!");
                    }
                }
                else
                {
                    Console.WriteLine("OOh! Invalid login credentials !!");
                    Console.ReadLine();
                    Menu();
                }
                Console.WriteLine("\nHit enter to continue...");
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        private static string readPassword()
        {
            char nextChar;
            string password = "";
            int len = 0;
            try
            {
                do
                {
                    nextChar = Console.ReadKey().KeyChar;

                    if (char.IsLetterOrDigit(nextChar) || char.IsPunctuation(nextChar) || char.IsSymbol(nextChar))
                    {
                        password += nextChar;
                        len++;
                        Console.Write("\b*");
                    }
                    if (nextChar == '\b' && len > 0)
                    {
                        Console.Write(" \b");
                        password = password.Remove(--len, 1);
                    }
                    else if (nextChar == '\b' && len <= 0)
                        Console.Write(" ");
                    if (nextChar == '\n' || nextChar == '\r')
                        Console.WriteLine();
                } while (nextChar != '\n' && nextChar != '\r');
                
            }
            catch (Exception e)
            {
                Console.WriteLine("\n" + e.Message);
            }
            return password;
        }
        private static void StartUp()
        {
            try
            {
                string fileName = "JobPortalSystem.jps";
                JobPortalSystemBLL systemBLL = new JobPortalSystemBLL();
                systemBLL.StartUp(fileName);
            }
            catch (JobPortalSystemException e)
            {
                Console.WriteLine("\nERROR WHILE STARTUP\n" + e.Message);
                Quit();
            }
        }
        private static void Quit()
        {
            InitializeConsole();
            Console.SetCursorPosition(Console.WindowWidth / 2, Console.WindowHeight / 3);
            Console.Write("Exiting");
            for (int i = 0; i < 5; i++)
            {
                Console.Write(".");
                Thread.Sleep(500);
            }
            Environment.Exit(0);
        }
    }
}

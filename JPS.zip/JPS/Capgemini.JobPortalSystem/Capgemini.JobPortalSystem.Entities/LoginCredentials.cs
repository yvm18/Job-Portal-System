﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.Entities
{
    /// <summary>
    /// Login Credentials Entity Class
    /// </summary>
    [Serializable]
    public class LoginCredentials
    {
        // Gets or Sets the User Type  associated with Login 
        // Returns: User Type(admin/user)
        public char? UserType { get; set; }
        // Gets or Sets the User Id associated with  Login
        // Returns: User Id
        public int? UserID { get; set; }
        // Gets or Sets the Password associated with Login
        // Returns:Password
        public string Password { get; set; }
    }
}

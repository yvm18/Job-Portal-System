﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.Entities
{
    [Serializable]
    public class LoginCredentials
    {
        public char? UserType { get; set; }
        public int? UserID { get; set; }
        public string Password { get; set; }
    }
}

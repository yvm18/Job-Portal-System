﻿using System;

namespace Capgemini.JobPortalSystem.Entities
{
    /// <summary>
    /// User Information Entity Class when a new user SignIn
    /// </summary>
    [Serializable]
    public class UserInformation
    {
        // Gets or Sets the User Id associated with SignIn
        // Returns: User Id which is auto-generated
        public int? UserID { get; set; }
        // Gets or Sets the Passowrd associated with SignIn
        // Returns: Passowrd
        public string Password { get; set; }
        // Gets or Sets the First Name associated with SignIn
        // Returns:First Name of the user
        public string FirstName { get; set; }
        // Gets or Sets the Last Name associated with SignIn
        // Returns: Last Name of the user
        public string LastName { get; set; }
        // Gets or Sets the Age of the user associated with SignIn
        // Returns: Age of the user
        public int? Age { get; set; }
        // Gets or Sets the Gender of the user associated with SignIn
        // Returns: Gender(M/F)
        public char? Gender { get; set; }
        // Gets or Sets the Address of the user associated with SignIn
        // Returns: Address
        public string Address { get; set; }
        // Gets or Sets the Phone No of the user associated with SignIn
        // Returns: Phone No
        public long? PhoneNo { get; set; }
        // Gets or Sets the User Type associated with SignIn
        // Returns: User Type(Admin/User)
        public char? UserType { get; set; }
        public override string ToString()
        {
            return $"\nUser ID: {this.UserID}\tFirstName: {this.FirstName}\tLastName: {this.LastName}\t" +
                $"Age: {this.Age}\tGender: {this.Gender}\tAddress: {this.Address}\t" +
                $"PhoneNo: {this.PhoneNo}\tUserType: {this.UserType}\n";
        }
    }
}

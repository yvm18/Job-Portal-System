﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.Entities
{
    [Serializable]
    public class JobDetails
    {
        public int? JobID { get; set; }
        public string Employer { get; set; }
        public string Address { get; set; }
        public long? ContactNumber { get; set; }
        public string ContactEmailID { get; set; }
        public string SkillsRequired { get; set; }
        public string Qualification { get; set; }
        public string Location { get; set; }
        public int? Salary { get; set; }
        public int? NoOfVacancies { get; set; }

        public override string ToString()
        {
            return $"\nJobId={this.JobID}\tEmployer={this.Employer}\tAddress={this.Address}\tContactNumber={this.ContactNumber}\t" +
                $"ContactEmailID={this.ContactEmailID}\tSkillsRequired={this.SkillsRequired}\t" +
                $"Qualification={this.Qualification}\tLocation={this.Location}\tSalary={this.Salary}\tVacancies={this.NoOfVacancies}\n";
        }
    }
}

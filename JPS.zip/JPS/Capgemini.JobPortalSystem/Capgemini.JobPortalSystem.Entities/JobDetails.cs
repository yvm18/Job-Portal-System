﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.Entities
{
    /// <summary>
    /// Job Details Entity Class
    /// </summary>
    [Serializable]
    public class JobDetails
    {
        // Gets or Sets the Job Id associated with a particular job
        // Returns: Job Id which is auto-generated
        public int? JobID { get; set; }
        // Gets or Sets the Employer(Company Name) associated with the job
        // Returns: Employer (Company Name)
        public string Employer { get; set; }
        // Gets or Sets the Address associated with the job
        // Returns: Address of the company
        public string Address { get; set; }
        // Gets or Sets the Contact Number associated with the job
        // Returns: Contact Number
        public long? ContactNumber { get; set; }
        // Gets or Sets the Email Id associated with the job
        // Returns: Email Id 
        public string ContactEmailID { get; set; }
        // Gets or Sets the Skills Reuired for the job
        // Returns: Skills required
        public string SkillsRequired { get; set; }
        // Gets or Sets the Qualification needed for  the job
        // Returns: Qualification
        public string Qualification { get; set; }
        // Gets or Sets the Location Preference associated with the job
        // Returns: Loaction
        public string Location { get; set; }
        // Gets or Sets the Salary associated with the job
        // Returns: Salary
        public int? Salary { get; set; }
        // Gets or Sets the No of vacancies associated with the job
        // Returns: No Of Vacancies
        public int? NoOfVacancies { get; set; }
        public override string ToString()
        {
            return $"\nJobId={this.JobID}\tEmployer={this.Employer}\tAddress={this.Address}\tContactNumber={this.ContactNumber}\t" +
                $"ContactEmailID={this.ContactEmailID}\tSkillsRequired={this.SkillsRequired}\t" +
                $"Qualification={this.Qualification}\tLocation={this.Location}\tSalary={this.Salary}\tVacancies={this.NoOfVacancies}\n";
        }
    }
}

﻿using Capgemini.JobPortalSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.JobPortalSystem.DataAccessLayer
{
    public abstract class JobPortalSystemBaseDAL
    {
        public abstract bool AddJob(JobDetails job, out int? jobId);
        public abstract JobDetails SearchJob(int? jobId);
        public abstract List<JobDetails> ViewAllJobs();
        public abstract bool EditJob(JobDetails job);
        public abstract bool DeleteJob(int? jobId);
        public abstract bool AddNewUser(UserInformation newUser, out int? userId);
        public abstract bool UpdateUser(UserInformation user);
        public abstract bool DeleteUser(int? userId);
        public abstract List<UserInformation> SearchUser(int? userId, string nameStart = null);
        public abstract List<UserInformation> ViewAllUsers();
        public abstract bool Login(char userType, int userID, string pass);
        public abstract void StartUp(string fileName);
        public abstract bool DeSerializeDetails(string fileName = "JobPortalSystem.jps");
        public abstract bool SerializeDetails(string fileName = "JobPortalSystem.jps");
    }
}

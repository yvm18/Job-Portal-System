﻿using Capgemini.JobPortalSystem.Entities;
using System;
using System.IO;
using System.Collections.Generic;
using System.Xml.Serialization;
using Capgemini.JobPortalSystem.Exceptions;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;

namespace Capgemini.JobPortalSystem.DataAccessLayer
{
    public class JobPortalSystemDAL
    {
        public static List<LoginCredentials> credentials = new List<LoginCredentials>();
        public static List<UserInformation> userInfo = new List<UserInformation>();
        public static List<JobDetails> jobs = new List<JobDetails>();
        public static ArrayList dummyData = new ArrayList();
        
        public bool AddJob(JobDetails job, out int? jobId)
        {
            jobId = -1;
            bool jobAdded = false;
            try
            {
                job.JobID = jobs[jobs.Count-1].JobID + 1;
                jobs.Add(job);
                jobId = job.JobID;
                jobAdded = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return jobAdded;
        }
        public JobDetails SearchJob(int jobId)
        {
            JobDetails job = null;
            try
            {
                job = jobs.Find(jb => jb.JobID == jobId);
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return job;
        }
        public List<JobDetails> ViewAllJobs()
        {
            return jobs;
        }
        public bool EditJob(JobDetails job)
        {
            bool jobEdited = false;
            JobDetails jb = new JobDetails();
            try
            {
                jb = jobs.Find(j => j.JobID == job.JobID);
                if (jb != null)
                {
                    jb.Employer = job.Employer;
                    jb.Address = job.Address;
                    jb.ContactNumber = job.ContactNumber;
                    jb.ContactEmailID = job.ContactEmailID;
                    jb.SkillsRequired = job.SkillsRequired;
                    jb.Qualification = job.Qualification;
                    jb.Location = job.Location;
                    jb.Salary = job.Salary;
                    jb.NoOfVacancies = job.NoOfVacancies;
                    jobEdited = SerializeDetails();
                }
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return jobEdited;
        }
        public bool DeleteJob(int jobId)
        {
            bool jobDeleted = false;
            try
            {
                jobs.Remove(jobs.Find(jb => jb.JobID == jobId));
                jobDeleted = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return jobDeleted;
        }
        public bool AddNewUser(UserInformation newUser, out int? userId)
        {
            userId = -1;
            bool userAdded = false;
            try
            {
                newUser.UserID = userInfo[userInfo.Count - 1].UserID + 1;
                userInfo.Add(newUser);
                credentials.Add(new LoginCredentials
                {
                    UserType = 'U',
                    UserID = newUser.UserID,
                    Password = newUser.Password
                });
                userId = newUser.UserID;
                userAdded = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userAdded;
        }
        public bool UpdateUser(UserInformation user)
        {
            bool userEdited = false;
            UserInformation usr = new UserInformation();
            try
            {
                usr = userInfo.Find(u => u.UserID == user.UserID);
                if (usr != null)
                {
                    usr.UserID = user.UserID;
                    usr.FirstName = user.FirstName;
                    usr.LastName = user.LastName;
                    usr.Age = user.Age;
                    usr.Gender = user.Gender;
                    usr.Address = user.Address;
                    usr.PhoneNo = user.PhoneNo;
                    usr.UserType = user.UserType;
                    usr.Password = user.Password;
                    userEdited = SerializeDetails();
                }
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userEdited;
        }
        public bool DeleteUser(int userId)
        {
            bool userDeleted = false;
            try
            {
                credentials.Remove(credentials.Find(crd => crd.UserID == userId));
                userInfo.Remove(userInfo.Find(usr => usr.UserID == userId));
                userDeleted = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userDeleted;
        }
        public UserInformation SearchUser(int userId, string password)
        {
            UserInformation user = null;
            try
            {
                user = userInfo.Find(usr => usr.UserID == userId && usr.Password == password);                
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return user;
        }
        public UserInformation SearchUser(int userId)
        {
            UserInformation user = null;
            try
            {
                user = userInfo.Find(usr => usr.UserID == userId);
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return user;
        }
        public List<UserInformation> ViewAllUsers()
        {
            return userInfo;
        }
        public bool Login(char userType, int userID, string pass)
        {
            if (credentials.Find(crd => crd.UserID == userID && crd.UserType == userType && crd.Password == pass) != null)
                return true;
            else
                return false;
        }
        public void StartUp(string fileName)
        {
            try
            {
                if (!File.Exists(fileName))
                    File.Create(fileName);
                if (new FileInfo(fileName).Length <= 0)
                {
                    List<LoginCredentials> dummyCredentials = new List<LoginCredentials>
                    {
                        new LoginCredentials {UserType='A', UserID=10000, Password="admin@yvm"},
                        new LoginCredentials {UserType='A', UserID=10001, Password="admin@psn"},
                        new LoginCredentials {UserType='A', UserID=10002, Password="admin@mmdd"},
                        new LoginCredentials {UserType='U', UserID=10003, Password="ayushi@2409"},
                        new LoginCredentials {UserType='U', UserID=10004, Password="sanki@skj"}
                    };
                    List<UserInformation> dummyUserInfo = new List<UserInformation>
                    {
                        new UserInformation {UserID=10000, Password="admin@yvm", FirstName="Yash", LastName="Maheshwari", Age=34, Gender='M', Address="ABC", PhoneNo=9432156571, UserType='A'},
                        new UserInformation {UserID=10001, Password="admin@psn", FirstName="Piyush", LastName="Singhal", Age=29, Gender='M', Address="DEF", PhoneNo=8765981234, UserType='A'},
                        new UserInformation {UserID=10002, Password="admin@mmdd", FirstName="Meenal", LastName="Sarda", Age=88, Gender='F', Address="GHI", PhoneNo=6678541237, UserType='A'},
                        new UserInformation {UserID=10003, Password="ayushi@2409", FirstName="Ayushi", LastName="Soni", Age=54, Gender='F', Address="JKL", PhoneNo=9087645090, UserType='U'},
                        new UserInformation {UserID=10004, Password="sanki@skj", FirstName="Sankalp", LastName="Jain", Age=45, Gender='M', Address="MNO", PhoneNo=8897123657, UserType='U'}
                    };
                    List<JobDetails> dummyJobs = new List<JobDetails>
                    {
                        new JobDetails {JobID=1000000, Employer="Capgemini", Address="ASD", ContactNumber=9987612341, ContactEmailID="asd@gmail.com", SkillsRequired="C++; HTML;", Qualification="B.Tech", Location="Gurgaon", Salary=200000, NoOfVacancies=10},
                        new JobDetails {JobID=1000001, Employer="Accenture", Address="FGH", ContactNumber=8871623456, ContactEmailID="fgh@gmail.com", SkillsRequired="C++; JAVA;", Qualification="B.Tech", Location="Pune", Salary=580000, NoOfVacancies=7},
                        new JobDetails {JobID=1000002, Employer="Wipro", Address="JKL", ContactNumber=6734512987, ContactEmailID="jkl@gmail.com", SkillsRequired="Web; .NET;", Qualification="B.Tech", Location="Chennai", Salary=1100000, NoOfVacancies=50},
                        new JobDetails {JobID=1000003, Employer="Stanford", Address="ZXC", ContactNumber=8876439881, ContactEmailID="ZXC@gmail.com", SkillsRequired="Full Stack; SQL;", Qualification="B.Tech", Location="Bangalore", Salary=545000, NoOfVacancies=23}
                    };

                    dummyData.Add(dummyCredentials);
                    dummyData.Add(dummyUserInfo);
                    dummyData.Add(dummyJobs);
                    SerializeDetails(fileName);
                    DeSerializeDetails(fileName);
                }
                else if (new FileInfo(fileName).Length != 0)
                {
                    DeSerializeDetails(fileName);
                }
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
        }
        private bool DeSerializeDetails(string fileName= "JobPortalSystem.jps")
        {
            bool dataDeserialized = false;
            try
            {
                using (FileStream fin = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                {
                    //XmlSerializer serializer = new XmlSerializer(typeof(ArrayList));
                    //dummyData = (ArrayList)serializer.Deserialize(fin);                    
                    BinaryFormatter formatter = new BinaryFormatter();
                    dummyData = (ArrayList)formatter.Deserialize(fin);
                    fin.Close();
                }
                credentials = (List<LoginCredentials>)dummyData[0];
                userInfo = (List<UserInformation>)dummyData[1];
                jobs = (List<JobDetails>)dummyData[2];
                dataDeserialized = true;
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return dataDeserialized;
        }
        private bool SerializeDetails(string fileName= "JobPortalSystem.jps")
        {
            bool dataSerialized = false;
            try
            {
                using (FileStream fout = new FileStream(fileName, FileMode.Open, FileAccess.Write))
                {
                    //XmlSerializer serializer = new XmlSerializer(typeof(ArrayList));
                    //serializer.Serialize(fout, dummyData);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fout, dummyData);
                    dataSerialized = true;
                    fout.Close();
                }
            }
            catch (Exception e)
             {
                throw new JobPortalSystemException(e.Message);
            }
            return dataSerialized;
        }
    }
}

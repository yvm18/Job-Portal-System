﻿using Capgemini.JobPortalSystem.Entities;
using System;
using System.IO;
using System.Collections.Generic;
using System.Xml.Serialization;
using Capgemini.JobPortalSystem.Exceptions;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;

namespace Capgemini.JobPortalSystem.DataAccessLayer
{
    public class JobPortalSystemDAL : JobPortalSystemBaseDAL
    {
        public static List<LoginCredentials> credentials = new List<LoginCredentials>();
        public static List<UserInformation> userInfo = new List<UserInformation>();
        public static List<JobDetails> jobs = new List<JobDetails>();
        public static ArrayList dummyData = new ArrayList();
        // Summary:
        //     Accept the instance of Capgemini.JobPortalSystem.Entities.JobDetails as a parameter,
        //     then adds it in the list, updating the entries in the file as well. Throws an exception
        //     in case of failure.
        //
        // Parameters:
        //   job:
        //     The instance of the job to be added.
        //   jobId: The auto-generated job id of the job, in case of success.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool AddJob(JobDetails job, out int? jobId)
        {
            jobId = -1;
            bool jobAdded = false;
            try
            {
                if (jobs.Count == 0)
                    job.JobID = 1000000;
                else if (jobs.Count == 1)
                    job.JobID = 1000001;
                else
                {
                    for (int i = 0; i < jobs.Count-1; i++)
                    {
                        if (jobs[i].JobID != jobs[i + 1].JobID - 1)
                        {
                            job.JobID = jobs[i].JobID + 1;
                            break;
                        }
                        else if (jobs[i].JobID == jobs[i + 1].JobID - 1 && jobs.Count - 2 == i)
                            job.JobID = jobs[jobs.Count - 1].JobID + 1;
                    }
                }
                jobs.Add(job);
                jobId = job.JobID;
                jobAdded = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return jobAdded;
        }
        // Summary:
        //     Searches for a job under the specified job Id.
        //     If found, returns the instance of the job.
        //
        // Parameters:
        //   jobId:
        //     The jobId of the job whose details needs to be displayed. 
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override JobDetails SearchJob(int? jobId)
        {
            JobDetails job = null;
            try
            {
                job = jobs.Find(jb => jb.JobID == jobId);
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return job;
        }
        //summary:
        //Lists all the jobs
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override List<JobDetails> ViewAllJobs()
        {
            return jobs;
        }
        //summary:
        // Accept the instance of Capgemini.JobPortalSystem.Entities.JobDetails as a parameter,
        //     then edits in the list, updating the entries in the file as well. Throws an exception
        //     in case of failure.
        //
        //Parameters:
        //   job:
        //     The instance of the job to edit.
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool EditJob(JobDetails job)
        {
            bool jobEdited = false;
            JobDetails jb = null;
            try
            {
                jb = jobs.Find(j => j.JobID == job.JobID);
                if (jb != null)
                {
                    jb.Employer = job.Employer;
                    jb.Address = job.Address;
                    jb.ContactNumber = job.ContactNumber;
                    jb.ContactEmailID = job.ContactEmailID;
                    jb.SkillsRequired = job.SkillsRequired;
                    jb.Qualification = job.Qualification;
                    jb.Location = job.Location;
                    jb.Salary = job.Salary;
                    jb.NoOfVacancies = job.NoOfVacancies;
                    jobEdited = SerializeDetails();
                }
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return jobEdited;
        }
        //summary:
        //  Accept the jobId from BLL, then removes the instance pointing to that id.
        //
        //Parameters:
        //   jobId:
        //      The jobId of the jobDetails list whose instance needs to be removed.
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool DeleteJob(int? jobId)
        {
            bool jobDeleted = false;
            try
            {
                jobs.Remove(jobs.Find(jb => jb.JobID == jobId));
                jobDeleted = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return jobDeleted;
        }
        // Summary:
        //     Accept the instance of Capgemini.JobPortalSystem.Entities.UserInformation as a parameter,
        //     then adds it in the list, updating the entries in the file as well. Throws an exception
        //     in case of failure.
        //
        // Parameters:
        //   newUser:
        //     The instance of the user to be added.
        //   userId:
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool AddNewUser(UserInformation newUser, out int? userId)
        {
            userId = -1;
            bool userAdded = false;
            try
            {
                if (userInfo.Count == 0)
                    newUser.UserID = 10000;
                else if (userInfo.Count == 1)
                    newUser.UserID = 10001;
                else
                {
                    for (int i = 0; i < userInfo.Count - 1; i++)
                    {
                        if (userInfo[i].UserID != userInfo[i + 1].UserID - 1)
                        {
                            newUser.UserID = userInfo[i].UserID + 1;
                            break;
                        }
                        else if (userInfo[i].UserID == userInfo[i + 1].UserID - 1 && userInfo.Count - 2 == i)
                            newUser.UserID = userInfo[userInfo.Count - 1].UserID + 1;
                    }
                }
                userInfo.Add(newUser);
                credentials.Add(new LoginCredentials { UserID=newUser.UserID, Password=newUser.Password, UserType=newUser.UserType });
                userId = newUser.UserID;
                userAdded = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userAdded;
        }
        // Summary:
        //     Accept the updated instance of Capgemini.JobPortalSystem.Entities.UserInformation,
        //     then updates the list, updating the entries in the file as well. Throws an exception
        //     in case of failure.
        //
        // Parameters:
        //   user:
        //     The instance of userInformation to be updated.
        //
        // Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool UpdateUser(UserInformation user)
        {
            bool userEdited = false;
            UserInformation usr = null;
            try
            {
                usr = userInfo.Find(u => u.UserID == user.UserID);
                if (usr != null)
                {
                    usr.UserID = user.UserID;
                    usr.FirstName = user.FirstName;
                    usr.LastName = user.LastName;
                    usr.Age = user.Age;
                    usr.Gender = user.Gender;
                    usr.Address = user.Address;
                    usr.PhoneNo = user.PhoneNo;
                    usr.UserType = user.UserType;
                    usr.Password = user.Password;
                    LoginCredentials cred = new LoginCredentials();
                    cred = credentials.Find(crd => crd.UserID == user.UserID);
                    cred.Password = user.Password;
                    cred.UserType = user.UserType;
                    userEdited = SerializeDetails();
                }
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userEdited;
        }
        //summary:
        //  Accept the jobId from BLL, then removes the instance pointing to that id.
        //
        //Parameters:
        //   userId:
        //      The userId of the UserInformation list whose instance needs to be removed.
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool DeleteUser(int? userId)
        {
            bool userDeleted = false;
            try
            {
                credentials.Remove(credentials.Find(crd => crd.UserID == userId));
                userInfo.Remove(userInfo.Find(usr => usr.UserID == userId));
                userDeleted = SerializeDetails();
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userDeleted;
        }
        //
        // Summary:
        //     Searches for a user under the specified userId and if found, returns it
        //     to the BLL. It can also find the name if it starts with a particular string.
        //
        //Parameters:
        //   userId:
        //      The userId of the user whose instance needs to be searched.
        //   nameStart: The starting string of a name.
        //
        // Exceptions:
        //   T:System.ApplicationException
        public override List<UserInformation> SearchUser(int? userId, string nameStart=null)
        {
            List<UserInformation> userList = null;
            try
            {
                if (userId != null)
                    userList = userInfo.FindAll(usr => usr.UserID == userId);
                else if (nameStart != null)
                    userList = userInfo.FindAll(usr => usr.FirstName.ToUpper().StartsWith(nameStart.ToUpper()));
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return userList;
        }
        //summary:
        //Lists all the Users
        //
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override List<UserInformation> ViewAllUsers()
        {
            return userInfo;
        }
        //summary:
        //     Accept the instance of Capgemini.JobPortalSystem.Entities.LoginCredentials as a parameter,
        //     then check for the details and if verified then successful login else Throws an exception
        //     in case of failure. 
        //Parameter:
        //     userType:
        //      checks whether the user is Admin or jobSeeker
        //     UserID:
        //      the instance of userId of the LoginCredentials to be verified
        //      pass:
        //       the instance of pass of the LoginCredentials to be verified
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool Login(char userType, int userID, string pass)
        {
            if (credentials.Find(crd => crd.UserID == userID && crd.UserType == userType && crd.Password == pass) != null)
                return true;
            else
                return false;
        }
        //
        // Summary:
        //     Loads/Generates the required resources before application startup. If unable to load,
        //     the applicatioin exits.
        //
        // Exceptions:
        //   T:System.ApplicationException
        //   T:Capgemini.JobPortalSystemException
        public override void StartUp(string fileName)
        {
            try
            {
                if (!File.Exists(fileName))
                    using (File.Create(fileName)) { }
                if (new FileInfo(fileName).Length <= 0)
                {
                    List<LoginCredentials> dummyCredentials = new List<LoginCredentials>
                    {
                        new LoginCredentials {UserType='A', UserID=10000, Password="admin@yvm"},
                        new LoginCredentials {UserType='A', UserID=10001, Password="admin@psn"},
                        new LoginCredentials {UserType='A', UserID=10002, Password="admin@mmdd"},
                        new LoginCredentials {UserType='U', UserID=10003, Password="ayushi@2409"},
                        new LoginCredentials {UserType='U', UserID=10004, Password="sanki@skj"}
                    };
                    List<UserInformation> dummyUserInfo = new List<UserInformation>
                    {
                        new UserInformation {UserID=10000, Password="admin@yvm", FirstName="Yash", LastName="Maheshwari", Age=34, Gender='M', Address="ABC", PhoneNo=9432156571, UserType='A'},
                        new UserInformation {UserID=10001, Password="admin@psn", FirstName="Piyush", LastName="Singhal", Age=29, Gender='M', Address="DEF", PhoneNo=8765981234, UserType='A'},
                        new UserInformation {UserID=10002, Password="admin@mmdd", FirstName="Meenal", LastName="Sarda", Age=88, Gender='F', Address="GHI", PhoneNo=6678541237, UserType='A'},
                        new UserInformation {UserID=10003, Password="ayushi@2409", FirstName="Ayushi", LastName="Soni", Age=54, Gender='F', Address="JKL", PhoneNo=9087645090, UserType='U'},
                        new UserInformation {UserID=10004, Password="sanki@skj", FirstName="Sankalp", LastName="Jain", Age=45, Gender='M', Address="MNO", PhoneNo=8897123657, UserType='U'}
                    };
                    List<JobDetails> dummyJobs = new List<JobDetails>
                    {
                        new JobDetails {JobID=1000000, Employer="Capgemini", Address="ASD", ContactNumber=9987612341, ContactEmailID="asd@gmail.com", SkillsRequired="C++; HTML;", Qualification="B.Tech", Location="Gurgaon", Salary=200000, NoOfVacancies=10},
                        new JobDetails {JobID=1000001, Employer="Accenture", Address="FGH", ContactNumber=8871623456, ContactEmailID="fgh@gmail.com", SkillsRequired="C++; JAVA;", Qualification="B.Tech", Location="Pune", Salary=580000, NoOfVacancies=7},
                        new JobDetails {JobID=1000002, Employer="Wipro", Address="JKL", ContactNumber=6734512987, ContactEmailID="jkl@gmail.com", SkillsRequired="Web; .NET;", Qualification="B.Tech", Location="Chennai", Salary=1100000, NoOfVacancies=50},
                        new JobDetails {JobID=1000003, Employer="Stanford", Address="ZXC", ContactNumber=8876439881, ContactEmailID="ZXC@gmail.com", SkillsRequired="Full Stack; SQL;", Qualification="B.Tech", Location="Bangalore", Salary=545000, NoOfVacancies=23}
                    };

                    dummyData.Add(dummyCredentials);
                    dummyData.Add(dummyUserInfo);
                    dummyData.Add(dummyJobs);
                    SerializeDetails(fileName);
                    DeSerializeDetails(fileName);
                }
                else if (new FileInfo(fileName).Length != 0)
                {
                    DeSerializeDetails(fileName);
                }
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
        }
        //summary:
        //   deserialize the data from the file when there is a request from BLL
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool DeSerializeDetails(string fileName= "JobPortalSystem.jps")
        {
            bool dataDeserialized = false;
            try
            {
                using (FileStream fin = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                {
                    //XmlSerializer serializer = new XmlSerializer(typeof(ArrayList));
                    //dummyData = (ArrayList)serializer.Deserialize(fin);                    
                    BinaryFormatter formatter = new BinaryFormatter();
                    dummyData = (ArrayList)formatter.Deserialize(fin);
                    fin.Close();
                }
                credentials = (List<LoginCredentials>)dummyData[0];
                userInfo = (List<UserInformation>)dummyData[1];
                jobs = (List<JobDetails>)dummyData[2];
                dataDeserialized = true;
            }
            catch (Exception e)
            {
                throw new JobPortalSystemException(e.Message);
            }
            return dataDeserialized;
        }
        //summary:
        // Accept the dummy data and seraialize the data and write the data in the file
        //Exceptions:
        //   T:System.ApplicationException:
        //   T:Capgemini.JobPortalSystem.Exceptions.JobPortalSystemException
        public override bool SerializeDetails(string fileName= "JobPortalSystem.jps")
        {
            bool dataSerialized = false;
            try
            {
                using (FileStream fout = new FileStream(fileName, FileMode.Open, FileAccess.Write))
                {
                    //XmlSerializer serializer = new XmlSerializer(typeof(ArrayList));
                    //serializer.Serialize(fout, dummyData);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fout, dummyData);
                    dataSerialized = true;
                    fout.Close();
                }
            }
            catch (Exception e)
             {
                throw new JobPortalSystemException(e.Message);
            }
            return dataSerialized;
        }
    }
}
